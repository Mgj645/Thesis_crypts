//
// Created by mgj on 7/1/18.
//

#include "sspm_v2.h"
unordered_set<string> usersV2;
unordered_set<string> usernamesV2;
string sepV2;
string sha1_keyV2(16, '\0');
vector<vector<string>> logV2;

string sspm_v2::applyFunction(string username, string password){
    string c = "";
    c.append(username);
    c.append(sepV2);
    c.append(password);

    return c;
}

void sspm_v2::dumpLog() {
    return ;
}

void sspm_v2::changeKey() {
    return ;
}

bool sspm_v2::Register(string username, string password){
    if (usernamesV2.find(username) == usernamesV2.end()){
        usernamesV2.insert(username);
        usersV2.insert(applyFunction(username, password));
        vector<string> toAdd;
        toAdd.push_back("add"); toAdd.push_back(username); toAdd.push_back(password);
        logV2.push_back(toAdd);
        return true;
    }
    else{
        return false;
    }
}
bool sspm_v2::Login(string username, string password) {
    return !(usersV2.find(applyFunction(username, password)) == usersV2.end());
}

bool sspm_v2::changePassword(string username, string password1, string password2){
    if (usersV2.find(applyFunction(username, password1)) == usersV2.end()){
        return false;
    }
    else{
        usersV2.erase(applyFunction(username, password1));
        usersV2.insert(applyFunction(username, password2));
        return true;
    }
}

bool sspm_v2::changeUsername(string username1, string password, string username2){
    if (usersV2.find(applyFunction(username1, password)) == usersV2.end()){
        return false;
    }
    else{
        usernamesV2.erase(applyFunction(username1, password));
        usernamesV2.insert(applyFunction(username2, password));
        usersV2.erase(applyFunction(username1, password));
        usersV2.insert(applyFunction(username2, password));
        return true;
    }
}

bool sspm_v2::deleteUser(string username, string password){
    if (usersV2.find(applyFunction(username, password)) == usersV2.end()){
        return false;
    }
    else{
        usersV2.erase(applyFunction(username, password));
        usernamesV2.erase(applyFunction(username, password));

        return true;
    }
}


sspm_v2::sspm_v2() {std::random_device rd;
    sepV2 = "!(";
    std::mt19937_64 gen{std::random_device{}()};
    std::uniform_int_distribution<short> dist{'a', 'z'};

    for(auto& c: sha1_keyV2)
        c = dist(gen);
}
