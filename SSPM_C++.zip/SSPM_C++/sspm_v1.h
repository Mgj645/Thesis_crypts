//
// Created by mgj on 6/29/18.
//

#ifndef SSPM_C_SSPM_V1_H
#define SSPM_C_SSPM_V1_H
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <bits/stdc++.h>
#include <string.h>

using namespace std;

class sspm_v1 {
private:
    string applyFunction(string username, string password);

public:
    bool Login(string username, string password);
    bool Register(string username, string password);
    bool changePassword(string username, string password1, string password2);
    bool changeUsername(string username1, string password, string username2);
    bool deleteUser(string username, string password);
    sspm_v1();
};


#endif //SSPM_C_SSPM_V1_H
