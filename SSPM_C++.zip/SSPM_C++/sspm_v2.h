//
// Created by mgj on 7/1/18.
//

#ifndef SSPM_C_SSPM_V2_H
#define SSPM_C_SSPM_V2_H
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <bits/stdc++.h>
#include <string.h>

using namespace std;

class sspm_v2 {
private:
    string applyFunction(string username, string password);
    void dumpLog();
    void changeKey();
public:
    bool Login(string username, string password);
    bool Register(string username, string password);
    bool changePassword(string username, string password1, string password2);
    bool changeUsername(string username1, string password, string username2);
    bool deleteUser(string username, string password);
    sspm_v2();

};


#endif //SSPM_C_SSPM_V2_H
