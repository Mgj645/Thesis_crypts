//
// Created by mgj on 6/28/18.
//

#ifndef SSPM_C_SSPM_V0_H
#define SSPM_C_SSPM_V0_H
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <bits/stdc++.h>

class sspm_v0 {
private:
    std::string applyFunction(std::string username, std::string password);

public:
    bool Login(std::string username, std::string password);
    bool Register(std::string username, std::string password);
    bool changePassword(std::string username, std::string password1, std::string password2);
    bool changeUsername(std::string username1, std::string password, std::string username2);
    bool deleteUser(std::string username, std::string password);
    sspm_v0();
};


#endif //SSPM_C_SSPM_V0_H
