#include "sspm_v0.h"
#include "sspm_v1.h"
#include "sspm_v2.h"

const int noUsers = 20;
const bool v0 = 0;
const bool v1 = 0;
const bool v2 = 1;

string usernames[noUsers];
string passwords[noUsers];

void simulateUsers() {
    string lineUser, linePassword;
    ifstream myfileUsers ("usernames.txt");
    ifstream myfilePass ("passwords.txt");

    if (myfileUsers.is_open() && myfilePass.is_open())
    {
        int i = 0;
        while ( getline (myfileUsers,lineUser) && getline (myfilePass,linePassword) && i< noUsers)
        {
            usernames[i] = lineUser;
            passwords[i] =  linePassword;
            i++;
        }
        myfileUsers.close();
        myfilePass.close();
    }
    else cout << "Unable to open file";
}

int main () {
    simulateUsers();

    sspm_v0 *s0 = new sspm_v0();
    sspm_v1 *s1 = new sspm_v1();
    sspm_v2 *s2 = new sspm_v2();

    for(int i = 0; i < noUsers; i++) {
        if(v0){
        s0->Register(usernames[i], passwords[i]);
        s0->Login(usernames[i], passwords[i]);
        }
        if(v1){
           s1->Register(usernames[i], passwords[i]);
           cout << s1->Login(usernames[i], passwords[i]) << endl;
        }

        if(v2){
            s2->Register(usernames[i], passwords[i]);
            cout << s2->Login(usernames[i], passwords[i]) << endl;
        }
    }

    free(s0); free(s1);
}