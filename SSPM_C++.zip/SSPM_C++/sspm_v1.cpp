//
// Created by mgj on 6/29/18.
//

#include "sspm_v1.h"
unordered_set<string> usersV1;
unordered_set<string> usernamesV1;
string sepV1;
string sha1_keyV1(16, '\0');


string sspm_v1::applyFunction(string username, string password){
    string c = "";
    c.append(username);
    c.append(sepV1);
    c.append(password);

    return c;
}

bool sspm_v1::Register(string username, string password){
    if (usernamesV1.find(username) == usernamesV1.end()){
        usernamesV1.insert(username);
        usersV1.insert(applyFunction(username, password));
        return true;
    }
    else{
        return false;
    }
}
bool sspm_v1::Login(string username, string password) {
    return !(usersV1.find(applyFunction(username, password)) == usersV1.end());
}

bool sspm_v1::changePassword(string username, string password1, string password2){
    if (usersV1.find(applyFunction(username, password1)) == usersV1.end()){
        return false;
    }
    else{
        usersV1.erase(applyFunction(username, password1));
        usersV1.insert(applyFunction(username, password2));
        return true;
    }
}

bool sspm_v1::changeUsername(string username1, string password, string username2){
    if (usersV1.find(applyFunction(username1, password)) == usersV1.end()){
        return false;
    }
    else{
        usernamesV1.erase(applyFunction(username1, password));
        usernamesV1.insert(applyFunction(username2, password));
        usersV1.erase(applyFunction(username1, password));
        usersV1.insert(applyFunction(username2, password));
        return true;
    }
}

bool sspm_v1::deleteUser(string username, string password){
    if (usersV1.find(applyFunction(username, password)) == usersV1.end()){
        return false;
    }
    else{
        usersV1.erase(applyFunction(username, password));
        usernamesV1.erase(applyFunction(username, password));

        return true;
    }
}


sspm_v1::sspm_v1() {std::random_device rd;
sepV1 = "!(";
    std::mt19937_64 gen{std::random_device{}()};
    std::uniform_int_distribution<short> dist{'a', 'z'};

    for(auto& c: sha1_keyV1)
        c = dist(gen);
}
