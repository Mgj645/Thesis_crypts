//
// Created by mgj on 6/28/18.
//

#include "sspm_v0.h"
using namespace std;

 unordered_set<string> users;
 string sep;
 string sha1_key(16, '\0');

sspm_v0::sspm_v0() {
    sep = "%|00%";
    std::random_device rd;
    std::mt19937_64 gen{std::random_device{}()};
    std::uniform_int_distribution<short> dist{'a', 'z'};

    for(auto& c: sha1_key)
        c = dist(gen);
}


string sspm_v0::applyFunction(string username, string password){
    string c = "";
    c.append(username);
    c.append(sep);
    c.append(password);

    return c;
}

bool sspm_v0::Register(string username, string password){
    if (users.find(applyFunction(username, password)) == users.end()){
        users.insert(applyFunction(username, password));
        return true;
    }
    else{
        return false;
    }
}
bool sspm_v0::Login(string username, string password) {
 return !(users.find(applyFunction(username, password)) == users.end());
}

bool sspm_v0::changePassword(string username, string password1, string password2){
    if (users.find(applyFunction(username, password1)) == users.end()){
        return false;
    }
    else{
        users.erase(applyFunction(username, password1));
        users.insert(applyFunction(username, password2));
        return true;
    }
}

bool sspm_v0::changeUsername(string username1, string password, string username2){
    if (users.find(applyFunction(username1, password)) == users.end()){
        return false;
    }
    else{
        users.erase(applyFunction(username1, password));
        users.insert(applyFunction(username2, password));
        return true;
    }
}

bool sspm_v0::deleteUser(string username, string password){
    if (users.find(applyFunction(username, password)) == users.end()){
        return false;
    }
    else{
        users.erase(applyFunction(username, password));
        return true;
    }
}
